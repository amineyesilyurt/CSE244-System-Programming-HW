/** 
 *  File:   grepfromFile.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW01
 *
 *  Created on March 5, 2016
 */


#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

#include "grepFunction.h"

int main(int argc, char *argv[]){

    FILE* fpLogFile;  /* point .log file */
	int fdFileToRead;     /* file descriptor */
	
    /* Usage */
	if(argc > 3 || argc < 3){
	    fprintf(stderr,"Usage : [%s] [fileName] [wordToSearch]",argv[0]);
		exit(1);
	}	
            /* opens the file given as an argument */
			if( ( fdFileToRead=open(argv[1] ,O_RDONLY) )== -1 ){	
			    perror("Could not open the file");
			    exit(1);    
			}
			/* opens the .log file */  
			if( (fpLogFile=fopen("gfF.log","a"))==NULL ){	
			    perror("Could not create log file");
			    exit(1);
			}
			/* prints the file name given as an argument into the .log file */	
			fprintf(fpLogFile,"\nFilename : %s\n\n",argv[1]);
			
			/* grep command works in here*/
			fnGrep(fpLogFile,fdFileToRead,argv[2]);
			
			/* closing files*/ 
			close(fdFileToRead);
		    fclose(fpLogFile);
		    
	return 0;
}

