/** 
 *  File:   grepfromFile.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW01
 *
 *  Created on March 5, 2016
 */

#ifndef GREP_FROM_FILE__
#define GREP_FROM_FILE__

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h> 
#include <limits.h>

#ifndef MAX_CANON
#define MAX_CANON 255
#endif

/**
 * Funtion Definition: This function searchs a word inside the input file and print
 *                     the line and column number of word to the log file
 *                     and print to terminal the total number of word.
 *                           
 * @param fpLogFile    a FILE pointer which point .log file                 
 * @param fdFileToRead a file descriptor which desciript to input file to read 
 * @param pszWordToSearch a char* which the point a word to search inside the input file                     
 */
void fnGrep(FILE* fpLogFile,int fdFileToRead, char* pszWordToSearch);

/**
 * Funtion Definition: This function reads a line from input file.
 *                      
 * @param fdFileToRead a file descriptor which desciript to input file to read
 * @param pszBufferLine a buffer readed line
 * @return iNumberBytesRead the number of bytes read, returns zero if nothing is found
 */
int fnGetLine(int fdFileToRead, char** pszBufferLine);

#endif

