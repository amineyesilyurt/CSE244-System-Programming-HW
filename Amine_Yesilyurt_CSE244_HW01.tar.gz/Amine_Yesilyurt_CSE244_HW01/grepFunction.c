/** 
 *  File:   grepfromFile.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW01
 *
 *  Created on March 5, 2016
 */

#include "grepFunction.h"

void fnGrep(FILE* fpLogFile,int fdFileToRead, char* pszWordToSearch){

	int iIndex,i;
	int iCountOfWord=0;
	char* pszBufferLine;    
    int iLengthOfWord;
	int iLengthOfLine;
	int iLineNumber=1;

    
    /* lenght of world which we search is detected*/
	iLengthOfWord = strlen(pszWordToSearch);
	
	/* Memory is allocated for each line read from the file */ 
	pszBufferLine = (char*)malloc(MAX_CANON);
    
	/*this loop will continue until whole file is read*/
	while( 0 != (iLengthOfLine = fnGetLine(fdFileToRead, &pszBufferLine)) )
	{	
	    /*if lenght of word is longer than lenght of line */
	    /* if buffer line points null character */	
		if( (*pszBufferLine == '\0') || (iLengthOfWord > iLengthOfLine)){
			++iLineNumber;
			continue;
		}
		
		else{		
			/*search given word inside line until line ends*/
			for(iIndex = 0; pszBufferLine[iLengthOfWord + iIndex] != '\0'; ++iIndex)
			{			    
				if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
					/*If word is found, prints the line number and column index of word to the .log file*/
					fprintf(fpLogFile,"     Line %d and column %d \n",iLineNumber,iIndex+1);
					/* increase the number of count of word*/
					++iCountOfWord;
				}
			}
			/* check last one for end of the line */
			if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
			        /*If word is found, prints the line number and column index of word to the .log file*/
					fprintf(fpLogFile,"     Line %d and column %d \n", iLineNumber,iIndex+1);
					/* increase the number of count of word*/
					++iCountOfWord;
			}
		}
		
		++iLineNumber; /*Increase line number*/
		
		/* to clean contents of buffer of line */
		for(i=0;i <=iLengthOfLine;++i )
		    pszBufferLine[i]=' ';
		/* free buffer line*/    
	    free(pszBufferLine);
	    /* set the NULL on buffer line */
	    pszBufferLine=NULL;
	    /* again allocate memory for Buffer Line */
		pszBufferLine = (char*)malloc(MAX_CANON);
		

	}
    /* free memory of Buffer Line  */
	free(pszBufferLine);
    
    /* report the number of total word */
	if(iCountOfWord != 0)	
		printf("\nTotal number of word %s : %d\n\n", pszWordToSearch, iCountOfWord);
	else{
		printf("\nThe word which searched is not found\n\n");
		fprintf(fpLogFile,"     The word which searched is not found\n");
    }
}


int fnGetLine(int fdFileToRead, char** pszBufferLine){	

	int  iBytesRead; /*return value which returned by read() function */
	int iNumberBytesRead=0; /* the number of bytes read*/
	
	/*if buffer is not enough ,for increase the buffer's size*/
     int s_iDoubling = 1;
	char* szTempBuffer;/*Needed when to double buffer size.For not to lose data*/
    
    /* read the line into the buffer line until see '\n' character or NULL character */
	while( 0 != (iBytesRead=read(fdFileToRead,(*pszBufferLine)+iNumberBytesRead, 1)) ){
	    
	    /* if could not read the file, send a message and exit the program*/
		if( -1 == iBytesRead ){
			perror("READING ERROR!");
			exit(1);
		}
		
		/*check if buffer is enough, if it is not, doubling buffer */
		else if( iNumberBytesRead == (MAX_CANON * s_iDoubling - 1 )){
				
			/* allocate memory for temporary buffer*/
			szTempBuffer = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of buffer of line to temporary buffer*/		
			strcpy(szTempBuffer, *pszBufferLine);
			
			/* free memory of buffer of line */
			free(*pszBufferLine);
			
			/*multiply the doubling with 2*/
			s_iDoubling *= 2;
			
			/*allocate doubling memory for pszBufferLine */
			*pszBufferLine = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of temporary buffer to buffer of line */
			strcpy(*pszBufferLine, szTempBuffer);
			
			/* free temporary buffer */
			free(szTempBuffer);
		}
		
		else if(  '\n'== (*pszBufferLine)[iNumberBytesRead] )
		{
			(*pszBufferLine)[iNumberBytesRead] = '\0';
			++iNumberBytesRead;
			return iNumberBytesRead;
		}
		
		++iNumberBytesRead;
	}
	
    /* if reached end of the file */
	(*pszBufferLine)[iNumberBytesRead] = '\0';
	
	return iNumberBytesRead;
}


/**
 *  P.S
 *  I used readline function on Chapter 4.1 of UNIX SYSTEMS Programming book
 *  which written by Kay A. Robbins , Steven Robbins.
 *     
 *  I also used stackoverflow.com site for to create my own algorithm.
 *  I did not copy completely same codes from these sources.
 *
 */



