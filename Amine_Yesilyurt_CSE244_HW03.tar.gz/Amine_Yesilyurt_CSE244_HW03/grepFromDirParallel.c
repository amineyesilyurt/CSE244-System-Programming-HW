/** 
 *  File:   grepFromDirParallel.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW03
 *
 *  Created on April 4, 2016
 */

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <dirent.h>


#define SIZE_OF_LINE_BUFFER 1024 
#define MAX_PATH_SIZE 1024
#define MAX_CANON 255

typedef int* intPtr;
static volatile sig_atomic_t doneflag=0;

/* ____GLOBAL VARIABLES_____*/
 int totalDirectory=0;


/**
 * Funtion Definition: This function searchs a word inside the input file and prints
 *                     the line and column number of word to the pipe.
 *                     Prints number of found word in the file into temporary file. 
 *                     
 *                                          
 * @param fdFileToRead a char pointer which point to input file to read 
 * @param pszWordToSearch a char* which the point a word to search inside the input file 
 * @param fd descriptor pipe
 * @return -1 if doneflag                      
 */
int  fnGrep(char* fdFileToRead, char* pszWordToSearch,int* fd);

/**
 * Funtion Definition: This function reads a line from input file.
 *                      
 * @param fdFileToRead a file descriptor which desciript to input file to read
 * @param pszBufferLine a buffer readed line
 * @return iNumberBytesRead the number of bytes read, returns zero if nothing is found
 */
int fnGetLine(int fdFileToRead, char** pszBufferLine);

/** This is a recursive function.It check if given path is a directory or not.
 *  If it is directory calls itself,else it calls 
 *  fnGrep function.Read from pipe and write to temporary file.
 *
 *  @param tempLogFile poits temporary log file 
 *  @param path the path current directory or file
 *  @param wordToSearch the word which to searched by user
 *  @param pipefd descriptor pipe
 */
int dirWalk(FILE* tempLogFile,const char* path,char * wordToSearch,intPtr pipefd);


//Signal handler function
void sigintHandler(int signo){
    doneflag = 1;
} /* copied from web */

/* START_OF_MAIN */
int main(int argc,char *argv[]){

    FILE* ptempFile;   /* for temporary file, to count total word number */
    FILE* tempLogFile;  /* point  .log file */
    FILE* fpLogFile; /* for gFD.log ,main log file */
    char fname[MAX_PATH_SIZE];
    char *plast;
    int iTotalNumOfWord=0;
    int numOfWordInEachFile;/* temp in icindeki sayilar icin*/
    int pipefd[2]; /*Using pipe for communication child to parent*/
    struct sigaction act;/*Set signal handler*/      
	char fifoName[MAX_PATH_SIZE];
	int childPidFifo;  /* for fifo */
	int i; /* for loop*/
	int fd_read,fd_write; /* for fifo */
	char line[MAX_PATH_SIZE];
	char buffer[MAX_PATH_SIZE];
	
    /* Usage */
	if(argc != 3){
	    fprintf(stderr,"Usage : [%s] [Directory Name] [wordToSearch]",argv[0]);
		exit(1);
	}
	
	/*Handle sigint*/
	act.sa_handler = sigintHandler;
	act.sa_flags = 0;
    if(sigemptyset(&act.sa_mask) == -1 || 
    	sigaction(SIGINT, &act, NULL) == -1){
        perror("Failed to set signal handler");
        return EXIT_FAILURE;
    }

	strcpy(fname,argv[1]);
    plast = strchr(fname,'\0')-1;
    
    if(*plast=='/')
        *plast='\0';
        
    /* opens the .log file */  
	if( (fpLogFile=fopen("gfD.log","w"))==NULL){	
	    perror("Could not create log file");
	    exit(1);
	}    	
	     
	/* opens the temporary .log file */  
	if( (tempLogFile=fopen("tempLogFile.log","w"))==NULL){	
	    perror("Could not create temporary log file");
	    exit(1);
	}

	
	/* goes into the directory */
	if(dirWalk(tempLogFile,fname,argv[2],pipefd) == -1){
	    system("cat /dev/null > gfD.log");
	    fprintf(fpLogFile,"Ctrl+C came :( ");
        remove("tempLogFile.log"); 
        remove("tempFile.txt"); 
        return 0;
	}
	
	/* closing temporary log file */ 
    fclose(tempLogFile);
    
    for(i=0; i<1; ++i){
        
        sprintf(fifoName,"%s%d","fifo_",i);
        	    
        if(mkfifo(fifoName,S_IRUSR | S_IWUSR)==-1){
            remove("tempLogFile.log"); 
            remove("tempFile.txt"); 
            perror("Failed mkfifo!\n");
            unlink(fifoName);
            return -1;
        }

        childPidFifo = fork();   /* sonra fork yaptik*/

        if (childPidFifo == -1) {
            perror("Failed to fork"); 
            return -1;
        }
        
        else if(childPidFifo==0){  /*CHILD*/                                      
         
        tempLogFile=fopen("tempLogFile.log","r"); 
        
        if( !( fd_write = open(fifoName,O_WRONLY)) ){
            
            perror("Cannot open fifo. Program closing...");
            return -1;
        }
        
        while( (fgets(line,MAX_PATH_SIZE,tempLogFile)) != NULL ){
            
            write(fd_write,line,MAX_PATH_SIZE);
        }
        close(fd_write);
        unlink(fifoName); 
        exit(0);
        
          
       } /* END OF CHILD*/
    
        
        /*parent reads from temporary file*/
        else /*PARENT*/
        {            
            
            
            if(doneflag){
            
                /*Interrupt child*/
                kill(childPidFifo, SIGINT);
                /*Read remaining data*/
                
                perror("Parent is interrupted by a signal(fifo) !!\n"); 
                system("cat /dev/null > gfD.log");/* clear the content of temp log */
                fprintf(fpLogFile," Ctrl+C came :( "); 
                remove("tempLogFile.log"); 
                remove("tempFile.txt");              
                return -1;
            } /* end of doneflag*/
            
            if( !( fd_read = open(fifoName,O_RDONLY)) ){
            
                perror("Cannot open fifo. Program closing...");
                exit(1);
            }
            while(read(fd_read,buffer,MAX_PATH_SIZE) > 0)
            {                
	  	     	fprintf(fpLogFile,"%s",buffer);
	  	    }
	  	    
            wait(NULL);	
            close(fd_read);
                          
        } /*END OF PARENT */
       
       
    }                                                       

    /*opens a temporary file for scan number of founded word in each file*/
    if( (ptempFile=fopen("tempFile.txt","r" ))==NULL	){
        perror("Failed open temp file!");
    }

    /* read the temporary file which keeps count of word for each file */
	while( !feof(ptempFile))
	{	
	    fscanf(ptempFile,"%d",&numOfWordInEachFile);
	    if(!feof(ptempFile)) 
	    iTotalNumOfWord +=numOfWordInEachFile;
	}
	/* closing the temporary file */
	fclose(ptempFile);   
    
    printf("\nTotal number of word '%s' : %d \n\n",argv[2],iTotalNumOfWord);
    
    /* deleting the temporary files */
   remove("tempFile.txt");
   remove("tempLogFile.log"); 
    
    return 0;
}/*END_OF_MAIN*/


int fnGrep(char* fdFileToRead, char* pszWordToSearch,int* fd){

	int iIndex,i;
	int iCountOfWord=0;
	char* pszBufferLine;    
    int iLengthOfWord;
	int iLengthOfLine;
	int iLineNumber=1;
    int inp;
    FILE* outTemp;
    char* tempBuffer;
    char fileName[MAX_PATH_SIZE];

    /* to open temporary file*/
    outTemp = fopen("tempFile.txt","a");
    
    /*to open the file to the read*/
    if( (inp=open(fdFileToRead,O_RDONLY))==-1 ){
        perror("Could not open the file to read!");
    }
    
    /* lenght of world which we search is detected*/
	iLengthOfWord = strlen(pszWordToSearch);
	
	/* Memory is allocated for each line read from the file */ 
	pszBufferLine = (char*)malloc(MAX_CANON);
	
	
	/* writes file name to the pipe */
	strcpy(fileName,fdFileToRead);
	strcat(fileName,"\n");
	close(fd[0]);
    write(fd[1], fileName, MAX_PATH_SIZE);
    
    
	/*this loop will continue until whole file is read*/
	while( 0 != (iLengthOfLine = fnGetLine(inp, &pszBufferLine)) )
	{	
	    /*if lenght of word is longer than lenght of line */
	    /* if buffer line points null character */	
		if( (*pszBufferLine == '\0') || (iLengthOfWord > iLengthOfLine)){
			++iLineNumber;
			continue;
		}
		
		else{
		
		    tempBuffer=(char*)malloc(MAX_CANON);		
			/*search given word inside line until line ends*/
			for(iIndex = 0; pszBufferLine[iLengthOfWord + iIndex] != '\0'; ++iIndex)
			{			    
				if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
					/*If word is found, prints the line number and column index of word to the pipe*/
					sprintf(tempBuffer,"     Line %d and column %d \n",iLineNumber,iIndex+1);
					close(fd[0]);
					write(fd[1], tempBuffer, SIZE_OF_LINE_BUFFER);
					/* increase the number of count of word*/
					++iCountOfWord;
				}
			}
			/* check last one for end of the line */
			if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0)
			{
			        /*If word is found, prints the line number and column index of word to the .log file*/
					sprintf(tempBuffer,"     Line %d and column %d \n", iLineNumber,iIndex+1);
					close(fd[0]);
					write(fd[1], tempBuffer, SIZE_OF_LINE_BUFFER);
					/* increase the number of count of word*/
					++iCountOfWord;
					free(tempBuffer);
			}
			
		}
		
		++iLineNumber; /*Increase line number*/
		
		
		/* to clean contents of buffer of line */
		for(i=0;i <=iLengthOfLine;++i )
		    pszBufferLine[i]=' ';
		/* free buffer line*/    
	    free(pszBufferLine);
	    /* set the NULL on buffer line */
	    pszBufferLine=NULL;
	    /* again allocate memory for Buffer Line */
		pszBufferLine = (char*)malloc(MAX_CANON);		

	}
    
    /* prints number of found word in this file into temporary file*/
    fprintf(outTemp,"%d ",iCountOfWord);
    
    if(doneflag){
        tempBuffer = (char*)malloc(MAX_CANON);
		sprintf(tempBuffer, "Child is interrupted...\n");
		close(fd[0]);
	    write(fd[1], tempBuffer, SIZE_OF_LINE_BUFFER);
		free(tempBuffer);
		return -1;
	}
    
    /* if countOfWord is zero ,prits to log file " Not Found"*/
    if(iCountOfWord == 0)
    {
        tempBuffer = (char*)malloc(MAX_CANON);
        sprintf(tempBuffer,"     Not Found ! \n");
        close(fd[0]);
		write(fd[1], tempBuffer, SIZE_OF_LINE_BUFFER);
        free(tempBuffer);
    }
    
    fclose(outTemp);
    /* free memory of Buffer Line  */
	free(pszBufferLine);
    close(inp);
   
}


int fnGetLine(int fdFileToRead, char** pszBufferLine){	

	int  iBytesRead; /*return value which returned by read() function */
	int iNumberBytesRead=0; /* the number of bytes read*/
	
	/*if buffer is not enough ,for increase the buffer's size*/
     int s_iDoubling = 1;
	char* szTempBuffer;/*Needed when to double buffer size.For not to lose data*/
    
    /* read the line into the buffer line until see '\n' character or NULL character */
	while( 0 != (iBytesRead=read(fdFileToRead,(*pszBufferLine)+iNumberBytesRead, 1)) ){
	    
	    /* if could not read the file, send a message and exit the program*/
		if( -1 == iBytesRead ){
			perror("READING ERROR!");
			exit(1);
		}
		
		/*check if buffer is enough, if it is not, doubling buffer */
		else if( iNumberBytesRead == (MAX_CANON * s_iDoubling - 1 )){
				
			/* allocate memory for temporary buffer*/
			szTempBuffer = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of buffer of line to temporary buffer*/		
			strcpy(szTempBuffer, *pszBufferLine);
			
			/* free memory of buffer of line */
			free(*pszBufferLine);
			
			/*multiply the doubling with 2*/
			s_iDoubling *= 2;
			
			/*allocate doubling memory for pszBufferLine */
			*pszBufferLine = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of temporary buffer to buffer of line */
			strcpy(*pszBufferLine, szTempBuffer);
			
			/* free temporary buffer */
			free(szTempBuffer);
		}
		
		else if(  '\n'== (*pszBufferLine)[iNumberBytesRead] )
		{
			(*pszBufferLine)[iNumberBytesRead] = '\0';
			++iNumberBytesRead;
			return iNumberBytesRead;
		}
		
		++iNumberBytesRead;
	}
	
    /* if reached end of the file */
	(*pszBufferLine)[iNumberBytesRead] = '\0';
	
	return iNumberBytesRead;
}



int dirWalk(FILE* tempLogFile,const char* path,char * wordToSearch,intPtr pipefd){
    
    char fname[MAX_PATH_SIZE];
    struct dirent *de;
    struct stat status;
    DIR* dir;
    pid_t childpid;
    char buffer[MAX_PATH_SIZE];
    int readReturnVal;
    ssize_t returnValue;
    int sizeOfBuffer = SIZE_OF_LINE_BUFFER;

    
    if((dir=opendir(path))==NULL)
    {   
        perror("Failed to open the directory"); 
        exit(1);       
    }
    
    while((de=readdir(dir))!=NULL){
        
       
        sprintf(fname,"%s/%s",path,de->d_name);
        
        if(strcmp(de->d_name,".") != 0 && strcmp(de->d_name,"..") !=0)
        {
            if(stat(fname,&status)==-1){
                perror("Stat Error!");
                break;
            }
            
            /* if it is directory*/
            if(S_ISDIR(status.st_mode))
            {
 
                dirWalk(tempLogFile,fname,wordToSearch,pipefd); /* recursive*/          
                ++totalDirectory; /* increase directory count */
            }
            
            /* if it is a file */
            if(!S_ISDIR(status.st_mode)){
            
                if(strchr(fname,'~')==NULL){
                
                    if(pipe(pipefd) == -1){   /* create pipe*/
				        perror("Failed to pipe");
				        return -1;
			        }

                    childpid = fork();   /* create fork */
   
                    if (childpid == -1) {
                        perror("Failed to fork"); 
                        return -1;
                    }
                    
                    /* writes to pipe */
                    else if(childpid==0){  /*CHILD*/                                      

                     if( (fnGrep(fname,wordToSearch,pipefd))== -1){
                        perror("Child pipe interrupt by a signal");
                        return -1;
                     }                      
                     exit(0);
                  
                   } /* END OF CHILD*/
                   
                    
                    /* parent reads from pipe */
                    else /*PARENT*/
                    {            
                        if(close(pipefd[1]) == -1){
                            perror("Failed to close unused write pipe(parent)");
                            return -1;
                        }
                        
                        if(doneflag){
                        
                            /*Interrupt child*/
                            kill(childpid, SIGINT);
                            /*Read remaining data*/
                            while(1){
                            
                          		while(readReturnVal = read(pipefd[0], buffer, sizeOfBuffer) , (returnValue == -1) && (errno == EINTR));
                          		
                              		if(readReturnVal == 0)  /* pipe icindekileri bitirene kadar okudu */
                              	        break;                         
                            }
                            perror("Parent is interrupted...\n");                           
                            return -1;
                        } /* end of doneflag*/
                        
                        
                        while(read(pipefd[0],buffer,MAX_PATH_SIZE) > 0)
                        { 
                            printf("%s",buffer); /* pipe'a yazdiklarimi ekrana yazdirdim */                             
            	  	     	fprintf(tempLogFile,"%s",buffer); /* pipe'a yazdiklarimi temporary bir dosyaya yazdirdim */
            	  	    }
            	  	    wait(0);	
                                      
                    } /*END OF PARENT */                                                                                 
                }                
            }
        }    
    }
   
    /*closing directory*/
    closedir(dir);  
}


   
