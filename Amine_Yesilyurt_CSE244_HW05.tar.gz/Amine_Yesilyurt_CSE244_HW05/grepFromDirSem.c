/** 
 *  File:   grepFromDirSem.c
 *  Author: Amine Yesilyurt 
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW05
 *
 *  Created on May 6, 2016
 */

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <dirent.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/sem.h>

#define MAX_SIZE 1024
#define MAX_LEN 255
#define MAX_PATH_SIZE 1024
#define MAX_CANON 255
#define SIZE_OF_LINE_BUFFER 1024
#define NUM_THREADS 500
#define FIFO_PERMS (S_IRWXU | S_IWGRP| S_IWOTH)
#define FIFO_NAME "AloneFifo"

static volatile sig_atomic_t doneflag=0;


/* _____________GLOBAL VARIABLES_____________*/
 FILE* logFile;
 int totalDirectory=0;
 int totalFile=0;
 int totalWord=0;
 char strFilePaths[NUM_THREADS][NUM_THREADS];
 char pszWordToSearch[MAX_SIZE];
 pthread_t threads[NUM_THREADS];
 sem_t semlock;
 /*____________END_OF_GLOBAL_________________*/
 
 
 
 
/**
 * Funtion Definition: This function searchs a word inside the input file and 
 *                     prints the line and column number of word to the fifo
 *                                                                   
 */
void* fnGrep( void * arg );




/**
 * Funtion Definition: This function reads a line from input file.
 *                      
 * @param fdFileToRead a file descriptor which desciript to input file to read
 * @param pszBufferLine a buffer readed line
 * @return iNumberBytesRead the number of bytes read, returns zero if nothing is found
 */
int fnGetLine(int fdFileToRead, char** pszBufferLine);



/** This is a recursive function.It check if given path is a directory or not.
 *  If it is directory calls itself,else it calls 
 *  fnGrep function by creating thread.
 *
 *  @param path the path current directory or file
 */
int dirWalk(const char* path);


pid_t r_wait(int *stat_loc);


/* Signal handler function  */
void sigintHandler(int signo){
    doneflag = 1;
}




/* START_OF_MAIN */
int main(int argc,char *argv[]){

    char fname[MAX_PATH_SIZE];
    char *plast;
    struct sigaction act;  /*Set signal handler*/      	
	char buffer[MAX_SIZE];
	int i;
	int requestfd;	
		
    /* Usage */
	if(argc != 3){
	    fprintf(stderr,"Usage : [%s] [Directory Name] [wordToSearch]",argv[0]);
		exit(1);
	}
		
	
	/*Handle sigint*/
	act.sa_handler = sigintHandler;
	act.sa_flags = 0;
    if(sigemptyset(&act.sa_mask) == -1 || 
    	sigaction(SIGINT, &act, NULL) == -1){
        perror("Failed to set signal handler");
        return EXIT_FAILURE;
    }



	strcpy(fname,argv[1]);
    plast = strchr(fname,'\0')-1;
    if(*plast=='/')
        *plast='\0';
     
   
   	if(strlen(argv[2])==1){
		perror("Word to search can not be one letter");
		exit(1);
	}
    
    /* create only one fifo*/ 
	if ((mkfifo(FIFO_NAME,FIFO_PERMS) == -1) && (errno != EEXIST))
	{
		perror("Server failed to create the fifo\n");
		return 1;
	}      
	
	
	
	/* aranacak kelimeyi global arraya kopyaladim */             
	strcpy( pszWordToSearch,argv[2]);
	
	
	/* semaphore initialization*/
	if(sem_init(&semlock,0,1)== -1){
		perror("Failed to initialize semephore");
		return -1;
	} 
	
	
	/* recursively reads files, create threads */
	if(dirWalk(fname) == -1){		
        return 0;
	}
	
	
	
	/* fifoyu okuma modunda actim */
	if( ((requestfd = open(FIFO_NAME, O_RDONLY) ) == -1))
	{
		if( unlink(FIFO_NAME) == -1 )
		{
			perror("Server failed to remove the fifo\n");
			return 1;
		}
		exit(1);
	} 
	   
	
	for(i=0;i<totalFile;++i){
		pthread_join(threads[i],NULL);
		
	}	
	
	logFile=fopen("gFD.log","w");
	
		 
  	if(doneflag){
  
		perror("Program is interrupted...\n");
		fprintf(logFile,"We caught Ctrl+C :( so all data removed");
		fclose(logFile);
	   	unlink(FIFO_NAME);                          
		return -1;
	} /* end of doneflag*/
	
	
	/* fifonun icindekileri okudum ve log dosyasina yazdim */
	while( read(requestfd,buffer,MAX_SIZE)>0 ){
		
		fprintf(logFile,"%s",buffer);
	}
	/*closing fifo and log file*/
	
	close(requestfd); 

	
	fclose(logFile);	  	
	
	if( unlink(FIFO_NAME) == -1 )
	{
		perror("Failed to remove the fifo\n");
		return 1;
	}
	
	printf("\nNumber of the word '%s': %d \n\n",pszWordToSearch,totalWord);
                                          
    
    return 0;
}/*END_OF_MAIN*/


int dirWalk(const char* path){
    
    char fname[MAX_PATH_SIZE];
    struct dirent *de;
    struct stat status;
    DIR* dir;
	
    
    if((dir=opendir(path))==NULL)
    {   
        perror("Failed to open the directory"); 
        exit(1);       
    }
    
    while((de=readdir(dir))!=NULL){
            
       	
        sprintf(fname,"%s/%s",path,de->d_name);
        
        if(strcmp(de->d_name,".") != 0 && strcmp(de->d_name,"..") !=0)
        {
        
        
            if(stat(fname,&status)==-1){
                perror("Stat Error!");
                break;
            }
                           
            
	        /* if it is directory*/
	        if(S_ISDIR(status.st_mode))
	        {
	        		
					/* increase directory count */ 
		    		++totalDirectory;   
					dirWalk(fname); /* recursive*/         		            	  
		    
        	}/* directory_end */
        	
        	
        	
        
			/* if it is a file */
			if(!S_ISDIR(status.st_mode)){
			
			    if(strchr(fname,'~')==NULL){
			    	
			    	/*dosya ismini global diziye kopyaladım*/
					strcpy(strFilePaths[totalFile],fname);
					pthread_create(&threads[totalFile],NULL,fnGrep,(void *)strFilePaths[totalFile]);
					++totalFile; 							                                                                    
			    }                
			}/* file_end */
						
				   
    	}
            
    }
    /*closing directory*/
    closedir(dir);
   	return 0;
 
}






void* fnGrep(void * arg ){

	FILE* fpTempFile;
	int iIndex,i;
	int count;
	char* pszBufferLine;    
    int iLengthOfWord;
	int iLengthOfLine;
	int iLineNumber=1;
    int inp;
  	char file[MAX_SIZE];
  	char tempFileName[MAX_SIZE];
  	char buffer[MAX_SIZE];
  	int requestfd;
  	
 	/* temporary log to keep lines and columns */
  	sprintf(tempFileName,"logfile_%ld",pthread_self());
 		
  	
  	/* temporary log i actim */
	fpTempFile=fopen(tempFileName,"w");
	
  	strcpy(file,(char*)arg);
 	
    
    /* hedef file i okuma modunda actim*/
    if( (inp=open( (char*)arg,O_RDONLY))==-1 )
    {
        perror("Could not open the file to read!");
        exit(1);
    }
	
	/* file in ismini temporary log a yazdim*/
	strcat(file,"\n");
    fprintf(fpTempFile,"\n%s",file);
    
    
    /* lenght of world which we search is detected*/
	iLengthOfWord = strlen(pszWordToSearch);
	
	/* Memory is allocated for each line read from the file */ 
	pszBufferLine = (char*)malloc(MAX_LEN);
    
  
    
    
	/*this loop will continue until whole file is read*/
	while( 0 != (iLengthOfLine = fnGetLine(inp, &pszBufferLine)) )
	{	
	    /*if lenght of word is longer than lenght of line */
	    /* if buffer line points null character */	
		if( (*pszBufferLine == '\0') || (iLengthOfWord > iLengthOfLine)){
			++iLineNumber;
			continue;
		}
		
		else{
				
			/*search given word inside line until line ends*/
			for(iIndex = 0; pszBufferLine[iLengthOfWord + iIndex] != '\0'; ++iIndex)
			{	
					    
				if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
					/*If word is found, prints the line number and column index of word to temporary file*/
					fprintf(fpTempFile,"     Line %d and column %d \n",iLineNumber,iIndex+1);	
					/* increase the number of count of word*/
					++count;
					++totalWord;/**global degisken*/					
				}
			}
			/* check last one for end of the line */
			if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0)
			{
			        /*If word is found, prints the line number and column index of word to the temporary file*/
					fprintf(fpTempFile,"     Line %d and column %d \n",iLineNumber,iIndex+1);				
					/* increase the number of count of word*/
					++count;
					++totalWord; /*global degisken*/
										
			}
			
		}
		
		++iLineNumber; /*Increase line number*/
		
		
		/* to clean contents of buffer of line */
		for(i=0;i <=iLengthOfLine;++i )
		    pszBufferLine[i]=' ';
		/* free buffer line*/    
	    free(pszBufferLine);
	    /* set the NULL on buffer line */
	    pszBufferLine=NULL;
	    /* again allocate memory for Buffer Line */
		pszBufferLine = (char*)malloc(MAX_LEN);		

	}
     
    /* if countOfWord is zero ,prits to temporary file " Not Found"*/
    if(count == 0)
		 fprintf(fpTempFile,"     Not Found ! \n");
    
    
	/* Ctrl+C gelince */
	/*if(doneflag){
		remove(tempFileName);
		logFile=fopen("gFD.log","w");
		fprintf(logFile,"We caught Ctrl+C :( so all data removed");
		fclose(logFile);
		unlink(FIFO_NAME);
		exit(1);
	}*/
    
    /* free memory of Buffer Line  */
	free(pszBufferLine);
    close(inp);
    fclose(fpTempFile); 


	/* temporary dosyayi okuma modunda acip icindekileri fifo ya yazacağım*/
	fpTempFile=fopen(tempFileName,"r");
		
	
	/*__________entry section______________________________*/
 	while(sem_wait(&semlock)==-1)   
 		if(errno != EINTR ){
 			fprintf(stderr,"Thread failed to lock semaphore \n");
 			return NULL;
 		}

	
	/*__________start  of critical section_______________*/
	
	/* opened server fifo in write mode */
	if ((requestfd = open(FIFO_NAME, O_WRONLY)) == -1)
	{
		if( unlink(FIFO_NAME) == -1 )
		{
			perror("Client failed to remove the fifo\n");
			return NULL;
		}
		exit(1);
	}
	/* bir dosya icin buldugum sonuclari satir satir fifo'ya yazdim*/
	while( fgets(buffer,MAX_SIZE,fpTempFile) != NULL){
		 write(requestfd,buffer,MAX_SIZE );
	}
	

	
	fclose(fpTempFile);
	remove(tempFileName);
	close(requestfd);

	
	/*____________exit section___________________________*/
	if(sem_post(&semlock)==-1)
		fprintf(stderr,"Thread failed to unlock semaphore\n");
	

	return NULL;

}


int fnGetLine(int fdFileToRead, char** pszBufferLine){	

	int  iBytesRead; /*return value which returned by read() function */
	int iNumberBytesRead=0; /* the number of bytes read*/
	
	/*if buffer is not enough ,for increase the buffer's size*/
     int s_iDoubling = 1;
	char* szTempBuffer;/*Needed when to double buffer size.For not to lose data*/
    
    /* read the line into the buffer line until see '\n' character or NULL character */
	while( 0 != (iBytesRead=read(fdFileToRead,(*pszBufferLine)+iNumberBytesRead, 1)) ){
	    
	    /* if could not read the file, send a message and exit the program*/
		if( -1 == iBytesRead ){
			perror("READING ERROR!");
			exit(1);
		}
		
		/*check if buffer is enough, if it is not, doubling buffer */
		else if( iNumberBytesRead == (MAX_LEN * s_iDoubling - 1 )){
				
			/* allocate memory for temporary buffer*/
			szTempBuffer = (char*) malloc(MAX_LEN * s_iDoubling);
			
			/* copy contents of buffer of line to temporary buffer*/		
			strcpy(szTempBuffer, *pszBufferLine);
			
			/* free memory of buffer of line */
			free(*pszBufferLine);
			
			/*multiply the doubling with 2*/
			s_iDoubling *= 2;
			
			/*allocate doubling memory for pszBufferLine */
			*pszBufferLine = (char*) malloc(MAX_LEN * s_iDoubling);
			
			/* copy contents of temporary buffer to buffer of line */
			strcpy(*pszBufferLine, szTempBuffer);
			
			/* free temporary buffer */
			free(szTempBuffer);
		}
		
		else if(  '\n'== (*pszBufferLine)[iNumberBytesRead] )
		{
			(*pszBufferLine)[iNumberBytesRead] = '\0';
			++iNumberBytesRead;
			return iNumberBytesRead;
		}
		
		++iNumberBytesRead;
	}
	
    /* if reached end of the file */
	(*pszBufferLine)[iNumberBytesRead] = '\0';
	
	return iNumberBytesRead;
}





























   
