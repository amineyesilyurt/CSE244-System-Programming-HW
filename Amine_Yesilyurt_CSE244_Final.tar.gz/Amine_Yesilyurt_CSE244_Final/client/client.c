/*
 * client.c
 * Simple FTP program with socket 
 * Amine Yesilyurt CSE 244 Final Project
 * Student Number: 131044004
 */
 
 /*
 *  REFERENCES: 
 *  1 https://www.youtube.com/watch?v=V6CohFrRNTo 
 *  2 https://github.com/gudipati/FTP-ClientServer
 *  3 https://github.com/NathanJCochran/ftp/blob/master/ftserve.c
 *  4 https://github.com/NathanJCochran/ftp/blob/master/ftclient.c
 */
 
#include <stdlib.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/types.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>


#define MAXSIZE 4096 /*max text line length*/
FILE* logFilePtr;
char clientID[50];
int socketfd;
char message[MAXSIZE]; 
static volatile sig_atomic_t doneflag = 0;
static void setdoneflag(int signo) { doneflag = 1; }

void fngetFileFromServer(char* token,char **argv);
void fnListServer(char **argv);
int fngenerateSocket(int port,char *addr);

/**
*	Signal handler for CTRL^C
*	@param int signum signal name
**/
void ctrlC(int signum)
{
	int intClientID;
	intClientID=atoi(clientID);
	fprintf(logFilePtr,"Client killed by CTRL+C\n");
    fclose(logFilePtr);
            
    /* send operation requests*/
    sprintf(message,"Client %d is killed by CTRL+C\n",getpid());
	send(socketfd, message, MAXSIZE, 0);
    kill(intClientID, SIGINT);    
	close(socketfd);
   	exit(signum);
}





int main(int argc, char **argv){
	
	char logFileName[50];
	char sendmsg[MAXSIZE];
	char recvmsg[MAXSIZE];
	time_t tcurrent;
	struct sockaddr_in servaddr;
	char *token,*dummy;
	struct sigaction ctrlc;
	
	ctrlc.sa_handler = ctrlC;
    ctrlc.sa_flags = 0;

	if((sigemptyset(&ctrlc.sa_mask) || sigaction(SIGINT, &ctrlc, NULL)) == -1){
		perror("Couldn't set signal handler for SIGINT");
		return 1;
	}
	 
	
	/* usage*/
	if (argc !=3) {
		printf("Usage: %s <IP address of the server> <port number>\n",argv[0]);
		exit(1);
	}
	
	
	
	/*Create a socket for the client */
	if ((socketfd = socket (AF_INET, SOCK_STREAM, 0)) <0){
		printf("ERROR in creating the socket\n");
		exit(2);		
	}
	
	/*Creation of the socket */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr= inet_addr(argv[1]);
	servaddr.sin_port =  htons(atoi(argv[2])); 
	
	
	/*Connection of the client to the socket */
	if (connect(socketfd, (struct sockaddr *) &servaddr, sizeof(servaddr))<0) {
		printf("ERROR in connecting to the server\n");
		exit(3);
	}
	
	/*open log file*/
	sprintf(logFileName,"ClientLogFile%d",getpid());
	logFilePtr = fopen(logFileName,"w");
	
	
	/* write connection time to log file*/
	tcurrent=time(NULL);
	fprintf(logFilePtr,"Connected Time: %s\n",ctime(&tcurrent));
	fflush(logFilePtr);	
	
	printf("Operation:_");
	
	/*send client ID to server*/
	sprintf(clientID,"%d",getpid());
	send(socketfd, clientID, MAXSIZE, 0);
	
	while (fgets(sendmsg, MAXSIZE, stdin) != NULL) {

		
	    /* send operation requests*/
		send(socketfd, sendmsg, MAXSIZE, 0);
				
  		dummy=sendmsg;
  		token=strtok(dummy," ");
  		
	  
		/* if operation listServer :*/
		if (strcmp("listServer\n",sendmsg)==0){
			/* calling listServer function */
			fnListServer(argv);
			fprintf(logFilePtr,"Executed 'listServer' command\n");
		}
		
		else if (strcmp("listLocal\n",sendmsg)==0)  {
			system("ls");
			printf("\n");
			fprintf(logFilePtr,"Executed 'listLocal' command\n");
		}
		
		else if(strcmp("get",token)==0){
					
			fngetFileFromServer(token,argv);	
		}
		
		else if(strcmp("put",token)==0){
			//fnsendFileToServer();
		}
		else if(strcmp("lsClients",token)==0){
			/* */	
		}
		else if(strcmp("help\n",sendmsg)==0){
			printf("\n");
			printf("*********************************************************\n");
			printf("*     listLocal        command list the local files     *\n");
			printf("*     listServer       command list the local files     *\n");
			printf("*     get <filename>   command get the file from server *\n");
			printf("*********************************************************\n");
			printf("\n");
		}
		else{
			printf("Invalid command, check command\n");
   		}
		printf("Operation:_");
	}
	
	return 0;
	
}


/*void fnsendFileToServer(){
		

}*/

void fnListServer(char **argv){
	
	char port[MAXSIZE];
   	char buff[MAXSIZE];
   	char control[MAXSIZE]="continue";
	int data_port,datasock;

	recv(socketfd, port, MAXSIZE,0);
	data_port=atoi(port);

	datasock=fngenerateSocket(data_port,argv[1]);

	while(strcmp("continue",control)==0){

		recv(datasock,control,MAXSIZE,0);

		if(strcmp("end",control)==0)
			break;

		recv(datasock, buff, MAXSIZE,0);
			printf("%s",buff);
	}
	

}

void fngetFileFromServer(char* token,char **argv){

	char port[MAXSIZE];
	char buffer[MAXSIZE];
	char char_num_blks[MAXSIZE];
	char char_num_last_blk[MAXSIZE];
	char message[MAXSIZE];
	int data_port;
	int datasock;
	int lSize;
	int num_blks;
	int num_last_blk;
	int i;
	FILE *fp;
			
	/*recive port number from server*/
	recv(socketfd, port, MAXSIZE,0);
	
	data_port=atoi(port);
	datasock=fngenerateSocket(data_port,argv[1]);
	
	token=strtok(NULL," \n");
	recv(socketfd,message,MAXSIZE,0);
	
	if(strcmp("1",message)==0){
	
		if((fp=fopen(token,"w"))==NULL)
			printf("Error in creating file\n");
		else
		{
			recv(socketfd, char_num_blks, MAXSIZE,0);
			num_blks=atoi(char_num_blks);
			
			for(i= 0; i < num_blks; i++) { 
				recv(datasock, buffer, MAXSIZE,0);
				fwrite(buffer,sizeof(char),MAXSIZE,fp);
				
			}
			recv(socketfd, char_num_last_blk, MAXSIZE,0);
			num_last_blk=atoi(char_num_last_blk);
			
			if (num_last_blk > 0){ 
				recv(datasock, buffer, MAXSIZE,0);
				fwrite(buffer,sizeof(char),num_last_blk,fp);
				
			}
			fclose(fp);
			printf("File download done.\n");
		}
	}
	else{
		printf("Error in opening file. Check filename\nUsage: put filename\n");
	}
}


int fngenerateSocket(int port,char *addr){

	int socketfd;
	struct sockaddr_in servaddr;


	/*Create a socket for the client*/
	if ((socketfd = socket (AF_INET, SOCK_STREAM, 0)) <0) {
		printf("ERROR in creating the socket (fngenerateSocket)\n");
		exit(4);
	}

	/*preparation of the socket address */
	memset(&servaddr, 0, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr= inet_addr(addr);
	servaddr.sin_port =  htons(port); 

	/*Connection of the client to the socket */
	if (connect(socketfd, (struct sockaddr *) &servaddr, sizeof(servaddr))<0) {
		printf("ERROR in creating data channel (fngenerateSocket)\n");
		exit(5);	
	}

	return(socketfd);
}



