/*
 * FileShareServer.c
 * Simple FTP program with socket 
 * Amine Yesilyurt CSE 244 Final Project
 * Student Number: 131044004
 */


/*
 *  REFERENCES: 
 *  1 https://www.youtube.com/watch?v=V6CohFrRNTo 
 *  2 https://github.com/gudipati/FTP-ClientServer
 *  3 https://github.com/NathanJCochran/ftp/blob/master/ftserve.c
 *  4 https://github.com/NathanJCochran/ftp/blob/master/ftclient.c
 */


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>

#define MAXSIZE 4096 /*max text line length*/
#define MAXCLIENT 8 /*maximum number of client connections*/

typedef struct {
	int id;
	int isAlive; /* if client is killed by client isAlive become -1 */
}clientsIDInfo;

clientsIDInfo arrayClientsID[50]; /* for lsClient operation*/
int numOfClients=0;


void fnLsClients();
void fnsendFiletoClient(char* token,int* data_port,int* connfd,char **argv);
void fnListServer(int* connfd,int* data_port,char **argv);
int fngenerateSocket(int port);
int fnaccept(int sock);

int main (int argc, char **argv){

	int listenfd, connfd, n;
	pid_t childpid;
	socklen_t clilen;
	char buf[MAXSIZE];
	int data_port=1024;	/*for data connection */
	struct sockaddr_in cliaddr, servaddr;                                       
	char *token,*dummy;
	clientsIDInfo clientID; /* for clients ID */
	char chClientID[50];
	int indexCurrentClient;
		
    /*usage*/
	if (argc !=2){
		printf("Usage: %s <port number>",argv[0]);
		exit(1);
	}
	
	/*Create a socket*/ 
	if ((listenfd = socket (AF_INET, SOCK_STREAM, 0)) <0){
		printf("ERROR in creating the socket\n");	
		exit(2);	
	}	
	
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);/*IP adresimi kullan*/

	if(atoi(argv[1])<=1024){
		printf("Port number must be greater than 1024\n");
		exit(3);
	}
	
	/* kullanici tarafindan girilen port numarasini kullan */
	servaddr.sin_port = htons(atoi(argv[1]));
	
	/* bind the socket */
	if(bind (listenfd, (struct sockaddr *) &servaddr, sizeof(servaddr)) < 0){
		printf("ERROR on binding\n");
		exit(4);
	}
	
	
	/* listen to the socket by creating a connection queue
	 * then wait for clients
	 */
	listen (listenfd, MAXCLIENT);
	
	printf("Server running...\n");
	
	for ( ; ; ){

		clilen = sizeof(cliaddr);
		
		/*accept a connection */
		connfd = accept (listenfd, (struct sockaddr *) &cliaddr, &clilen);
		
		if(connfd<0){
			printf("ERROR on accept (main)");
		}


		/********FORK fork() function***************/
		
		if ( (childpid = fork ()) == 0 ) {//CHILD PROCESS
			
			
			printf("fork() created for client requests\n");
			
			//close listening socket
			close (listenfd);
			
			data_port=1024;
			
			/* get ClientID from client */
			if((n = recv(connfd, chClientID,MAXSIZE,0)) > 0){
			
				clientID.id=atoi(chClientID);
				printf("Client ID : %d  is connected to server\n",clientID.id);
				clientID.isAlive=1; /* client is alive */
				arrayClientsID[numOfClients]=clientID;
				indexCurrentClient=numOfClients;				
				++numOfClients;	
			}
			else
				printf("ClientID can not recieve\n");
				
			
			while( (n = recv(connfd, buf, MAXSIZE,0)) > 0){
			
				printf("%d requests operation:  %s",clientID.id,buf);
			
   				dummy=buf;
   				token=strtok(dummy," ");
   				
   				
				
				if (strcmp("listServer\n",buf)==0){
					fnListServer(&connfd,&data_port,argv);
				}
				
				if (strcmp("get",token)==0){
					fnsendFiletoClient(token,&data_port,&connfd,argv);
				} 
				
				/* When client kill itself*/
				if(strcmp("Client",buf)==0){
					clientID.isAlive=-1; /* client died by client.c */
					arrayClientsID[indexCurrentClient]=clientID;
					
				}
				
				if(strcmp("lsClients\n",buf)==0){
					fnLsClients();
					
				}
				
			}// END OF while ( (n = recv(connfd, buf, MAXSIZE,0)) > 0)

			if (n < 0)
				printf("Read error\n");

			exit(0);
		
		} // END OF CHILD PROCESS
		else
			wait(0);
		
		//close socket of the server
		close(connfd);
		
	} // end of for(;;)
	
	return 0;
}



void fnLsClients(){

	int i;		
		
	for(i=0;i<numOfClients;++i){
		if(arrayClientsID[numOfClients].isAlive==1)
		printf("%d",arrayClientsID[numOfClients].id);	
	}
	

}
void fnsendFiletoClient(char* token,int* data_port,int* connfd,char **argv){

	char port[MAXSIZE];
	char buffer[MAXSIZE];
	char char_num_blks[MAXSIZE];
	char char_num_last_blk[MAXSIZE];
	int datasock;
	int lSize;
	int num_blks;
	int num_last_blk;
	int i;
	FILE *fp;
	
	token=strtok(NULL," \n");
	
	*data_port=*data_port+1;
	
	if(*data_port==atoi(argv[1])){
		*data_port=*data_port+1;
	}
	sprintf(port,"%d",*data_port);
	datasock=fngenerateSocket(*data_port);//creating socket for data connection
	send(*connfd, port,MAXSIZE,0);//sending port no. to client
	datasock=fnaccept(datasock);//accepting connnection by client
	
	if ((fp=fopen(token,"r"))!=NULL)
	{
		//size of file
		send(*connfd,"1",MAXSIZE,0);
		fseek (fp , 0 , SEEK_END);
		lSize = ftell (fp);
		rewind (fp);
		num_blks = lSize/MAXSIZE;
		num_last_blk = lSize%MAXSIZE; 
		sprintf(char_num_blks,"%d",num_blks);
		send(*connfd, char_num_blks, MAXSIZE, 0);
		
		for(i= 0; i < num_blks; i++) { 
			fread (buffer,sizeof(char),MAXSIZE,fp);
			send(datasock, buffer, MAXSIZE, 0);
			
		}
		sprintf(char_num_last_blk,"%d",num_last_blk);
		send(*connfd, char_num_last_blk, MAXSIZE, 0);
		
		if (num_last_blk > 0) { 
			fread (buffer,sizeof(char),num_last_blk,fp);
			send(datasock, buffer, MAXSIZE, 0);
			//cout<<buffer<<endl;
		}
		fclose(fp);
		printf("File upload done.\n");
		
	}
	else{
		send(*connfd,"0",MAXSIZE,0);
	}

}


void fnListServer(int* connfd,int* data_port,char **argv){
	
	FILE *in;
	char temp[MAXSIZE],port[MAXSIZE];
	int datasock;
	(*data_port)=(*data_port)+1;

	if((*data_port)==atoi(argv[1])){
		(*data_port)=(*data_port)+1;
	}

	sprintf(port,"%d",*data_port);
	datasock=fngenerateSocket(*data_port);/*creating socket for data connection */
	send(*connfd, port,MAXSIZE,0);/*sending data connection port no. to client */
	datasock=fnaccept(datasock);/*accepting connection from client */

	if(!(in = popen("ls", "r"))){
		printf("ERROR in popen (fnListLocal)");
	}

	while(fgets(temp, sizeof(temp), in)!=NULL){
		send(datasock,"continue",MAXSIZE,0);
		send(datasock, temp, MAXSIZE, 0);
	}

	send(datasock,"end",MAXSIZE,0);
	pclose(in);	

}

int fngenerateSocket(int port){

	int listenfd;
	struct sockaddr_in dataservaddr;


	/*Create a socket */
	if ((listenfd = socket (AF_INET, SOCK_STREAM, 0)) <0){
		printf("ERROR in creating the data socket (fngenerateSocket)\n");
		exit(5);		
	}


	/* preparation of the socket address */
	dataservaddr.sin_family = AF_INET;
	dataservaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	dataservaddr.sin_port = htons(port);

	if ((bind (listenfd, (struct sockaddr *) &dataservaddr, sizeof(dataservaddr))) <0){
		printf("ERROR in binding the data socket\n");
		exit(6);	
	}

	/*listen to the socket*/
	listen (listenfd, 1);

	return(listenfd);
}


int fnaccept(int sock){

	int dataconnfd;
	socklen_t dataclilen;
	struct sockaddr_in datacliaddr;

	dataclilen = sizeof(datacliaddr);
	
	/*accept a connection */
	if ((dataconnfd = accept (sock, (struct sockaddr *) &datacliaddr, &dataclilen)) <0) {
		printf("ERROR in accepting the data socket (fnaccept)\n");
		exit(7);
	
	}

	return(dataconnfd);
}



