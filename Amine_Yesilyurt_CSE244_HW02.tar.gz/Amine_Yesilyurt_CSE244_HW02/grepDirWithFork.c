/** 
 *  File:   grepDirWithFork.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW02
 *
 *  Created on March 18, 2016
 */

#include "grepDirWithFork.h"

void fnGrep(FILE* fpLogFile,char* fdFileToRead, char* pszWordToSearch){

	int iIndex,i;
	int iCountOfWord=0;
	char* pszBufferLine;    
    int iLengthOfWord;
	int iLengthOfLine;
	int iLineNumber=1;
    int inp;
    FILE* outTemp;
    
    /* to open temporary file*/
    outTemp = fopen("tempFile.txt","a");
    
    /*to open the file to the read*/
    inp=open(fdFileToRead,O_RDONLY);
   
    /* lenght of world which we search is detected*/
	iLengthOfWord = strlen(pszWordToSearch);
	
	/* Memory is allocated for each line read from the file */ 
	pszBufferLine = (char*)malloc(MAX_CANON);
    
	/*this loop will continue until whole file is read*/
	while( 0 != (iLengthOfLine = fnGetLine(inp, &pszBufferLine)) )
	{	
	    /*if lenght of word is longer than lenght of line */
	    /* if buffer line points null character */	
		if( (*pszBufferLine == '\0') || (iLengthOfWord > iLengthOfLine)){
			++iLineNumber;
			continue;
		}
		
		else{		
			/*search given word inside line until line ends*/
			for(iIndex = 0; pszBufferLine[iLengthOfWord + iIndex] != '\0'; ++iIndex)
			{			    
				if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
					/*If word is found, prints the line number and column index of word to the .log file*/
					fprintf(fpLogFile,"     Line %d and column %d \n",iLineNumber,iIndex+1);
					
					/* increase the number of count of word*/
					++iCountOfWord;
				}
			}
			/* check last one for end of the line */
			if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0)
			{
			        /*If word is found, prints the line number and column index of word to the .log file*/
					fprintf(fpLogFile,"     Line %d and column %d \n", iLineNumber,iIndex+1);
					
					/* increase the number of count of word*/
					++iCountOfWord;
			}
		}
		
		++iLineNumber; /*Increase line number*/
		
		/* to clean contents of buffer of line */
		for(i=0;i <=iLengthOfLine;++i )
		    pszBufferLine[i]=' ';
		/* free buffer line*/    
	    free(pszBufferLine);
	    /* set the NULL on buffer line */
	    pszBufferLine=NULL;
	    /* again allocate memory for Buffer Line */
		pszBufferLine = (char*)malloc(MAX_CANON);
		

	}
    
    /* prints number of found word in this file into temporary file*/
    fprintf(outTemp,"%d ",iCountOfWord);
    
    /* if countOfWord is zero ,prits to log file " Not Found"*/
    if(iCountOfWord == 0)
    {
        fprintf(fpLogFile,"     Not Found ! \n");
    }
    fclose(outTemp);
    /* free memory of Buffer Line  */
	free(pszBufferLine);
    close(inp);
   
}


int fnGetLine(int fdFileToRead, char** pszBufferLine){	

	int  iBytesRead; /*return value which returned by read() function */
	int iNumberBytesRead=0; /* the number of bytes read*/
	
	/*if buffer is not enough ,for increase the buffer's size*/
     int s_iDoubling = 1;
	char* szTempBuffer;/*Needed when to double buffer size.For not to lose data*/
    
    /* read the line into the buffer line until see '\n' character or NULL character */
	while( 0 != (iBytesRead=read(fdFileToRead,(*pszBufferLine)+iNumberBytesRead, 1)) ){
	    
	    /* if could not read the file, send a message and exit the program*/
		if( -1 == iBytesRead ){
			perror("READING ERROR!");
			exit(1);
		}
		
		/*check if buffer is enough, if it is not, doubling buffer */
		else if( iNumberBytesRead == (MAX_CANON * s_iDoubling - 1 )){
				
			/* allocate memory for temporary buffer*/
			szTempBuffer = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of buffer of line to temporary buffer*/		
			strcpy(szTempBuffer, *pszBufferLine);
			
			/* free memory of buffer of line */
			free(*pszBufferLine);
			
			/*multiply the doubling with 2*/
			s_iDoubling *= 2;
			
			/*allocate doubling memory for pszBufferLine */
			*pszBufferLine = (char*) malloc(MAX_CANON * s_iDoubling);
			
			/* copy contents of temporary buffer to buffer of line */
			strcpy(*pszBufferLine, szTempBuffer);
			
			/* free temporary buffer */
			free(szTempBuffer);
		}
		
		else if(  '\n'== (*pszBufferLine)[iNumberBytesRead] )
		{
			(*pszBufferLine)[iNumberBytesRead] = '\0';
			++iNumberBytesRead;
			return iNumberBytesRead;
		}
		
		++iNumberBytesRead;
	}
	
    /* if reached end of the file */
	(*pszBufferLine)[iNumberBytesRead] = '\0';
	
	return iNumberBytesRead;
}



void dirWalk(FILE* fpLogFile,const char* path,char * wordToSearch){
    
    char fname[MAX_PATH_SIZE];
    struct dirent *de;
    struct stat status;
    DIR* dir;
    pid_t childpid;

      
    if((dir=opendir(path))==NULL)
    {   
        perror("Failed to open the directory"); 
        exit(1);       
    }
    
    while((de=readdir(dir))!=NULL){
        
       
        sprintf(fname,"%s/%s",path,de->d_name);
        
        if(strcmp(de->d_name,".") != 0 && strcmp(de->d_name,"..") !=0)
        {
            if(stat(fname,&status)==-1){
                perror("Stat Error!");
                break;
            }
            if(S_ISDIR(status.st_mode))
            {
                dirWalk(fpLogFile,fname,wordToSearch); /* recursive*/
            }
            if(!S_ISDIR(status.st_mode)){
            
                if(strchr(fname,'~')==NULL){
                    
                    /* creating child process in here*/                             
                    if ((childpid = fork()) == -1) 
                    {                        
                        perror("Fork failed!");
                        exit(1);                                
                    }
                    /* child process */
                    else if(childpid==0)
                    {   
                        /* prints file path and file name to log file */                     
                        fprintf(fpLogFile,"\n%s   \n\n",fname);
                        /* calls fnGrep */     
                        fnGrep(fpLogFile,fname,wordToSearch);                  
                        exit(0);
                    }
                    else /* parent wait */
                        wait(NULL);                                                           
                }
               
            }
        }    
    }
   /* Alternative code: while ((wpid = wait(&st)) > 0); */
   
    /*closing directory*/
    closedir(dir);
    
}

