/** 
 *  File:   grepDirWithFork.h
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW02
 *
 *  Created on March 18, 2016
 */
 
#ifndef GREP_DIRECTORY_WITH_FORK_
#define GREP_DIRECTORY_WITH_FORK_

#include<dirent.h>
#include <ctype.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>


#define MAX_PATH_SIZE 1024

/**
 * Funtion Definition: This function searchs a word inside the input file and prints
 *                     the line and column number of word to the log file.
 *                     Prints number of found word in the file into temporary file. 
 *                     
 *                           
 * @param fpLogFile    a FILE descriptor which point .log file                 
 * @param fdFileToRead a char pointer which point to input file to read 
 * @param pszWordToSearch a char* which the point a word to search inside the input file                     
 */
void fnGrep(FILE* fpLogFile,char* cpFileToRead, char* pszWordToSearch);

/**
 * Funtion Definition: This function reads a line from input file.
 *                      
 * @param fdFileToRead a file descriptor which desciript to input file to read
 * @param pszBufferLine a buffer readed line
 * @return iNumberBytesRead the number of bytes read, returns zero if nothing is found
 */
int fnGetLine(int fdFileToRead, char** pszBufferLine);

/** This is a recursive function.It check if given path is a directory or not.
 *  If it is directory calls itself,else it calls 
 *  fnGrep function.
 *  @param fpLogFile poits gfD.log 
 *  @param path the path current directory or file
 *  @param wordToSearch the word which to searched by user
 */
void dirWalk(FILE* fpLogFile,const char* path,char * wordToSearch);

#endif
