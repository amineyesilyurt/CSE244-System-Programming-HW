/** 
 *  File:   grepfromDir.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW02
 *
 *  Created on March 18, 2016
 */


#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>

#include "grepDirWithFork.h"


/* START_OF_MAIN */
int main(int argc,char *argv[]){


    FILE* ptempFile;   /* for temporary file */
    FILE*  fpLogFile;  /* point .log file */
    char fname[MAX_PATH_SIZE];
    char *plast;
    int iTotalNumOfWord=0;
    int numOfWordInEachFile;
   
          
	
	
    /* Usage */
	if(argc != 3){
	    fprintf(stderr,"Usage : [%s] [Directory Name] [wordToSearch]",argv[0]);
		exit(1);
	}
	
	strcpy(fname,argv[1]);
    plast = strchr(fname,'\0')-1;
    
    if(*plast=='/')
        *plast='\0';
        	
	     
	/* opens the .log file */  
	if( (fpLogFile=fopen("gfD.log","w"))==NULL){	
	    perror("Could not create log file");
	    exit(1);
	}

	
	/* goes into the directory */
	dirWalk(fpLogFile,fname,argv[2]);
	
	
	
	/* closing log file*/ 
    fclose(fpLogFile);
    
    /*opens a temporary file for scan number of founded word in each file*/
    if( (ptempFile=fopen("tempFile.txt","r" ))==NULL	){
        perror("Failed open temp file!");
    }


    /* read the temporary file which keeps count of word for each file */
	while( !feof(ptempFile))
	{	
	    fscanf(ptempFile,"%d",&numOfWordInEachFile);
	    if(!feof(ptempFile)) 
	    iTotalNumOfWord +=numOfWordInEachFile;
	}
	/* closing the temporary file */
	fclose(ptempFile);   
    
    printf("\nTotal number of word '%s' : %d \n\n",argv[2],iTotalNumOfWord);
    
    /* deleting the temporary file */
    remove("tempFile.txt");
    
    
    return 0;
}/*END_OF_MAIN*/


   
