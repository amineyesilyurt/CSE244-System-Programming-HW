/** 
 *  File:   grepFromDirTh.c
 *  Author: Amine Yesilyurt 
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming HW04
 *
 *  Created on April 23, 2016
 */

#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <dirent.h>
#include <pthread.h>



#define MAX_SIZE 1024
#define MAX_LEN 255
#define MAX_PATH_SIZE 1024
#define MAX_CANON 255
#define SIZE_OF_LINE_BUFFER 1024


typedef int* intPtr;
static volatile sig_atomic_t doneflag=0;



/* ____GLOBAL VARIABLES_____*/
 int totalDirectory=0;
 int totalFile=0;
 char strFilePaths[MAX_PATH_SIZE][MAX_CANON];
 char pszWordToSearch[MAX_SIZE ];
 int pipefd[2]; /*Using pipe for communication child to parent*/



/**
 * Funtion Definition: This function searchs a word inside the input file and 
 *                     prints the line and column number of word to the pipe.
 *                                                               
 * @return doneflag olursa -1 dondurur olmazsa dosyadaki aranan kelime sayısını  
 *                  dondurur    
 */
void* fnGrep( void* fileName );



/**
 * Funtion Definition: This function reads a line from input file.
 *                      
 * @param fdFileToRead a file descriptor which desciript to input file to read
 * @param pszBufferLine a buffer readed line
 * @return iNumberBytesRead the number of bytes read, returns zero if nothing is found
 */
int fnGetLine(int fdFileToRead, char** pszBufferLine);



/** This is a recursive function.It check if given path is a directory or not.
 *  If it is directory calls itself,else it calls 
 *  fnGrep function.Read from pipe and write to temporary file.
 *
 *  @param path the path current directory or file
 */
int dirWalk(const char* path);



/* thread safe functions */
ssize_t r_read(int fd, void *buf, size_t size);
ssize_t r_write(int fd, void *buf, size_t size);
pid_t r_wait(int *stat_loc);


/* Signal handler function  */
void sigintHandler(int signo){
    doneflag = 1;
}



/* START_OF_MAIN */
int main(int argc,char *argv[]){

	FILE* logFile;
    char fname[MAX_PATH_SIZE];
    char *plast;
    int iTotalNumOfWord=0;
    void* numOfWordInEachFile;
    struct sigaction act;  /*Set signal handler*/      	
	pthread_t threads[255];
	char buffer[MAX_SIZE];
    int readReturnVal;
    ssize_t returnValue;
	int i,j;
	pid_t childpid;
	int sizeOfBuffer = MAX_SIZE;
		
		
		
    /* Usage */
	if(argc != 3){
	    fprintf(stderr,"Usage : [%s] [Directory Name] [wordToSearch]",argv[0]);
		exit(1);
	}
		
	
	/*Handle sigint*/
	act.sa_handler = sigintHandler;
	act.sa_flags = 0;
    if(sigemptyset(&act.sa_mask) == -1 || 
    	sigaction(SIGINT, &act, NULL) == -1){
        perror("Failed to set signal handler");
        return EXIT_FAILURE;
    }



	strcpy(fname,argv[1]);
    plast = strchr(fname,'\0')-1;
    if(*plast=='/')
        *plast='\0';
     
     
        
    /* log file i actim */
	logFile=fopen("gFD.log","w");
	
	
	/* dosya isimlerini global 2D array'a  atadim ve ve toplam dosya sayisini buldum*/
	if(dirWalk(fname) == -1){		
        return 0;
	}
	
	
	/* aranacak kelimeyi global arraya kopyaladim */             
	strcpy( pszWordToSearch,argv[2]);
	
	
	/* dosya sayisi kadar thread olustu */
	for(i=0;i<totalFile;++i){
	
	
		/* PIPE */
		if(pipe(pipefd) == -1){   
		    perror("Failed to pipe");
		    return -1;
   		}
		
		childpid=fork();
		
		
		
		if (childpid == -1) {
			perror("Failed to fork"); 
			return -1;
		}



		/* CHILD */
		if(childpid==0)
		{		
			pthread_create(&threads[i],NULL,fnGrep,(void *)strFilePaths[i]);
			sleep(1);
			exit(0);
			
		}
		
		
		
		/* PARENT */
		else
		{
		
			if(close(pipefd[1]) == -1){
		        perror("Failed to close unused write pipe(parent)");
		        return -1;
		    }
		    
		    if(doneflag){
		    
		        /*Interrupt child*/
		        kill(childpid, SIGINT);
		        /*Read remaining data*/
		        perror("Parent is interrupted...\n");
		        system("cat /dev/null > gfD.log");/* clear the content of temp log */
		        sprintf(buffer,"Parent is interrupted...");
		        fprintf(logFile,buffer,strlen(buffer)+1);                           
		        return -1;
		    } /* end of doneflag*/
		    
		    
		    while(r_read(pipefd[0],buffer,MAX_SIZE) > 0)
		    { 
		        printf("%s",buffer); /* pipe'a yazdiklarimi ekrana yazdirdim */                             
	  	     	fprintf(logFile,"%s",buffer); /* pipe'a yazdiklarimi temporary bir dosyaya yazdirdim */
	  	    }
	  	    
	  	   while (r_wait(NULL) > 0);
		}
		
	}	
	
	
	 
		
	for(i=0;i<totalFile;++i){
		
		pthread_join(threads[i],&numOfWordInEachFile);
		
	}
	
	printf("TOTAL WORD : %d \n",iTotalNumOfWord);
    fclose(logFile); 
                                                     
    
    return 0;
}/*END_OF_MAIN*/





void* fnGrep(void* fileName ){


	int iIndex,i;
	void* iCountOfWord=0;
	int count;
	char* pszBufferLine;    
    int iLengthOfWord;
	int iLengthOfLine;
	int iLineNumber=1;
    int inp;
    char* tempBuffer;
  	char file[1024];
	
  	
  	strcpy(file,(char*)fileName);
 
    
    /*dosyayi okuma modunda actim*/
    if( (inp=open( file,O_RDONLY))==-1 ){
        perror("Could not open the file to read!");
        exit(1);
    }

   
    /* dosyanın ismini pipe a yazdim */
	strcpy(file,(char *)fileName);
	strcat(file,"\n");
	close(pipefd[0]);
    r_write(pipefd[1],file, MAX_PATH_SIZE); 
    
    /* lenght of world which we search is detected*/
	iLengthOfWord = strlen(pszWordToSearch);
	
	/* Memory is allocated for each line read from the file */ 
	pszBufferLine = (char*)malloc(MAX_LEN);
    
    
	/*this loop will continue until whole file is read*/
	while( 0 != (iLengthOfLine = fnGetLine(inp, &pszBufferLine)) )
	{	
	    /*if lenght of word is longer than lenght of line */
	    /* if buffer line points null character */	
		if( (*pszBufferLine == '\0') || (iLengthOfWord > iLengthOfLine)){
			++iLineNumber;
			continue;
		}
		
		else{
		
		    tempBuffer=(char*)malloc(MAX_LEN);		
			/*search given word inside line until line ends*/
			for(iIndex = 0; pszBufferLine[iLengthOfWord + iIndex] != '\0'; ++iIndex)
			{			    
				if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0){
					/*If word is found, prints the line number and column index of word to the pipe*/
					sprintf(tempBuffer,"     Line %d and column %d \n",iLineNumber,iIndex+1);
					close(pipefd[0]);
					r_write(pipefd[1], tempBuffer, MAX_SIZE);
					/* increase the number of count of word*/
					++count;					
				}
			}
			/* check last one for end of the line */
			if(strncmp(pszBufferLine+iIndex, pszWordToSearch, iLengthOfWord) == 0)
			{
			        /*If word is found, prints the line number and column index of word to the .log file*/
					sprintf(tempBuffer,"     Line %d and column %d \n", iLineNumber,iIndex+1);
					close(pipefd[0]);
					r_write(pipefd[1], tempBuffer, MAX_SIZE);
					/* increase the number of count of word*/
					++count;
					free(tempBuffer);					
			}
			
		}
		
		++iLineNumber; /*Increase line number*/
		
		
		/* to clean contents of buffer of line */
		for(i=0;i <=iLengthOfLine;++i )
		    pszBufferLine[i]=' ';
		/* free buffer line*/    
	    free(pszBufferLine);
	    /* set the NULL on buffer line */
	    pszBufferLine=NULL;
	    /* again allocate memory for Buffer Line */
		pszBufferLine = (char*)malloc(MAX_LEN);		

	}
 
    
    /* if countOfWord is zero ,prits to log file " Not Found"*/
    if(iCountOfWord == 0)
    {
        tempBuffer = (char*)malloc(MAX_LEN);
        sprintf(tempBuffer,"     Not Found ! \n");
        close(pipefd[0]);
		r_write(pipefd[1], tempBuffer, MAX_SIZE);
        free(tempBuffer);
    }
    
    /* free memory of Buffer Line  */
	free(pszBufferLine);
    close(inp);
    *((int*)(iCountOfWord))=count;
    return iCountOfWord;
}









int fnGetLine(int fdFileToRead, char** pszBufferLine){	

	int  iBytesRead; /*return value which returned by read() function */
	int iNumberBytesRead=0; /* the number of bytes read*/
	
	/*if buffer is not enough ,for increase the buffer's size*/
     int s_iDoubling = 1;
	char* szTempBuffer;/*Needed when to double buffer size.For not to lose data*/
    
    /* read the line into the buffer line until see '\n' character or NULL character */
	while( 0 != (iBytesRead=r_read(fdFileToRead,(*pszBufferLine)+iNumberBytesRead, 1)) ){
	    
	    /* if could not read the file, send a message and exit the program*/
		if( -1 == iBytesRead ){
			perror("READING ERROR!");
			exit(1);
		}
		
		/*check if buffer is enough, if it is not, doubling buffer */
		else if( iNumberBytesRead == (MAX_LEN * s_iDoubling - 1 )){
				
			/* allocate memory for temporary buffer*/
			szTempBuffer = (char*) malloc(MAX_LEN * s_iDoubling);
			
			/* copy contents of buffer of line to temporary buffer*/		
			strcpy(szTempBuffer, *pszBufferLine);
			
			/* free memory of buffer of line */
			free(*pszBufferLine);
			
			/*multiply the doubling with 2*/
			s_iDoubling *= 2;
			
			/*allocate doubling memory for pszBufferLine */
			*pszBufferLine = (char*) malloc(MAX_LEN * s_iDoubling);
			
			/* copy contents of temporary buffer to buffer of line */
			strcpy(*pszBufferLine, szTempBuffer);
			
			/* free temporary buffer */
			free(szTempBuffer);
		}
		
		else if(  '\n'== (*pszBufferLine)[iNumberBytesRead] )
		{
			(*pszBufferLine)[iNumberBytesRead] = '\0';
			++iNumberBytesRead;
			return iNumberBytesRead;
		}
		
		++iNumberBytesRead;
	}
	
    /* if reached end of the file */
	(*pszBufferLine)[iNumberBytesRead] = '\0';
	
	return iNumberBytesRead;
}











int dirWalk(const char* path){
    
    char fname[MAX_PATH_SIZE];
    struct dirent *de;
    struct stat status;
    DIR* dir;
    pid_t childpid;
    char buffer[MAX_PATH_SIZE];
    int readReturnVal;
    ssize_t returnValue;
    int sizeOfBuffer = SIZE_OF_LINE_BUFFER;

    
    if((dir=opendir(path))==NULL)
    {   
        perror("Failed to open the directory"); 
        exit(1);       
    }
    
    while((de=readdir(dir))!=NULL){
        
       
        sprintf(fname,"%s/%s",path,de->d_name);
        
        if(strcmp(de->d_name,".") != 0 && strcmp(de->d_name,"..") !=0)
        {
            if(stat(fname,&status)==-1){
                perror("Stat Error!");
                break;
            }
            
            /* if it is directory*/
            if(S_ISDIR(status.st_mode))
            {
  				dirWalk(fname); /* recursive*/         
                ++totalDirectory; /* increase directory count */
            }
            
            /* if it is a file */
            if(!S_ISDIR(status.st_mode)){
            
                if(strchr(fname,'~')==NULL){
                
                	/* dosya ismini global diziye kopyaladım*/
					strcpy(strFilePaths[totalDirectory],fname);
		    		++totalFile; 
		    		                                                                            
                }                
            }
        }    
    }
   
    /*closing directory*/
    closedir(dir);  
}








ssize_t r_read(int fd, void *buf, size_t size) {
	ssize_t retval;
	while (retval = read(fd, buf, size), retval == -1 && errno == EINTR) ;
	return retval;
};








/* Kitaptan alindi */
ssize_t r_write(int fd, void *buf, size_t size)
{
	char *bufp;
	size_t bytestowrite;
	ssize_t byteswritten;
	size_t totalbytes;

	for (bufp = buf, bytestowrite = size, totalbytes = 0;
		bytestowrite > 0;
		bufp += byteswritten, bytestowrite -= byteswritten)
	{
		byteswritten = write(fd, bufp, bytestowrite);
		if ((byteswritten) == -1 && (errno != EINTR))
			return -1;
		if (byteswritten == -1)
			byteswritten = 0;
		totalbytes += byteswritten;
	}
	return totalbytes;
}

pid_t r_wait(int *stat_loc) {
   int retval;

   while (((retval = wait(stat_loc)) == -1) && (errno == EINTR)) ;
   return retval;


}





   
