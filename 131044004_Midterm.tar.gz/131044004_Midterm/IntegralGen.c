/** 
 *  File:   Client.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming Midterm
 *
 *  Created on April 22, 2016
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>
#include <sys/wait.h>
#include <string.h>
#include <math.h>

#define DEBUG

#define PI 3.14159265
#define BILLION 1000000000L
#define MILLION 1000000L
#define H 0.000001
#define FIFO_NAME "serverFifo"
#define MAX_SIZE 1024
#define SIZE 255
#define FIFO_PERMS (S_IRWXU | S_IWGRP| S_IWOTH)

typedef struct clientMessage{
	
	char fifoName[255];
	char function[255];

}client_t;

int IntegralGen(int resolution,int maxNumOfClients);
ssize_t r_write(int fd, void *buf, size_t size); /*Taken from book*/
int IntegralOperation(char* str);

static volatile sig_atomic_t doneflag = 0;
static void setdoneflag(int signo) { doneflag = 1; }
static int clientsCounter=0;

int main(int argc, char *argv[])
{
	int resolution;
	int maxNumOfClients;
	struct sigaction act;
	
	if( (argc != 3) || (argv[1][0] != '-') || (argv[2][0] != '-') )
	{
		fprintf(stderr,"Usage: %s -<resolution(ms)> -<max # of clients>\n",argv[0]);
		return 1;
	}
	
	resolution = atoi(argv[1]);
	maxNumOfClients = -atoi(argv[2]);
	
	/* set up signal handler */
	act.sa_handler = setdoneflag; 
	act.sa_flags = 0;
	
	if ((sigemptyset(&act.sa_mask) == -1) || (sigaction(SIGINT, &act, NULL) == -1))
	{
		perror("Failed to set SIGINT handler");
		return 1;
	}

    return IntegralGen(resolution,maxNumOfClients);
}

int IntegralGen(int resolution,int maxNumOfClients)
{
	FILE* fpTxt;
	char buffer[MAX_SIZE];
	char result[MAX_SIZE];
	int childpid;
	int clients[maxNumOfClients];
	int requestfd;
	char clientFifoName[SIZE];
	char functions[6][MAX_SIZE];
	int i;
	char strFunc[10];
	client_t message;
	
	/*ilk önce altı dosyayı okuyup icindeki fonksiyonlari stringlere atiyorum.*/
	for(i=0;i<6;++i){
	
		sprintf(buffer,"f%d.txt",i+1);

		if( (fpTxt=fopen(buffer,"r"))==NULL ){
			perror("Cannot open txt file\n");
			return 1;
		} 
		fgets(&functions[i][0],MAX_SIZE,fpTxt);
		fclose(fpTxt);
	}
	
	
	if ((mkfifo(FIFO_NAME,FIFO_PERMS) == -1) && (errno != EEXIST))
	{
		perror("Server failed to create the fifo\n");
		return 1;
	}
	
	
	
	while( !doneflag)
	{
#ifdef DEBUG
		fprintf(stderr, "Parent: Waiting to open fifo in write mode by client...\n");
#endif
		/*server fifoyu okuma modunda actim */
		if( ((requestfd = open(FIFO_NAME, O_RDONLY) ) == -1))
		{
			if( unlink(FIFO_NAME) == -1 )
			{
				perror("Server failed to remove the fifo\n");
				return 1;
			}
			exit(1);
		}
		
		
		if( ++clientsCounter > maxNumOfClients ){
			printf("You exceed the max client capacity\n");	
		}		
		
		
		/* struct seklinde okudum */
		read(requestfd, &message, sizeof(client_t));		
		close(requestfd);
#ifdef DEBUG
		fprintf(stderr,"message: %s,%s read from client, fifo closed.\n",message.function,message.fifoName);
		fprintf(stderr,"fork process!\n");
#endif

		childpid=fork();
		
		if(childpid<0)
		{
			perror("Server failed to fork\n");
			return 1;
		}
		
		/* CHILD*/	
		if(childpid ==0)
		{	
#ifdef DEBUG
			fprintf(stderr, "Child%d: Waiting to open fifo in read mode by client...\n",getpid());
#endif
			/* sonucu clientFifo ya yazacagim */
			if ((clients[clientsCounter] = open(message.fifoName, O_WRONLY)) == -1)
			{
				if( unlink(message.fifoName) == -1 )
				{
					perror("Client failed to remove the fifo\n");
					return 1;
				}
				exit(1);
			}
			
			sprintf(buffer,"Result is %d ",IntegralOperation(message.function));
			
			if(r_write(clients[clientsCounter], buffer, strlen(buffer)+1) != (strlen(buffer)+1))
			{
				perror("Failed to write from fj.txt \n");
				return 1;
			} 
			close(clients[clientsCounter]);
		    exit(1);
		}
		sleep(1);

	} /* END OF while(1) */
	
	close(requestfd);
	if( unlink(FIFO_NAME) == -1 )
	{
		perror("Failed to remove the fifo\n");
		return 1;
	}	

	return 0;
}

/*Taken from book*/
ssize_t r_write(int fd, void *buf, size_t size)
{
	char *bufp;
	size_t bytestowrite;
	ssize_t byteswritten;
	size_t totalbytes;

	for (bufp = buf, bytestowrite = size, totalbytes = 0;
		bytestowrite > 0;
		bufp += byteswritten, bytestowrite -= byteswritten)
	{
		byteswritten = write(fd, bufp, bytestowrite);
		if ((byteswritten) == -1 && (errno != EINTR))
			return -1;
		if (byteswritten == -1)
			byteswritten = 0;
		totalbytes += byteswritten;
	}
	return totalbytes;
}

int IntegralOperation(char* str){

	int i;
	int sum=0;
	
	i= (int)(str[0]-'0');
	sum += i;
	i= (int)(str[2]-'0');
	sum += i;
	return 10;	
}
	

