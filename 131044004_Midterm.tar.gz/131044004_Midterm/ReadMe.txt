Bu ödevde client pid'si ile fifo oluşturuyor.
Client, oluşturduğu fifonun ismini ve aldığı fonksiyon isimlerini(fi ve fj), struct'a atayıp daha sonra bu struct'ı server'ın oluşturduğu fifo(main fifo)'ya yazıyor. 
Server struct'ı okuduğu fonskiyonlarla herhangi bir işlem yapmıyor(Integral hesaplaması yok.)
Server, struct'tan okuduğu fifo ismini yazma modunda açıyor ve result olarak sabit 10 sayısını bu fifoya yazıyor.
Client en son kendisine gelen sonucu log file'a yazıyor. 

