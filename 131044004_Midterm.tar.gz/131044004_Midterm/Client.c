/** 
 *  File:   Client.c
 *  Author: Amine Yesilyurt <amine.yesilyurt@gmail.com>
 *  Student Number: 131044004
 * 
 *  CSE244 - System Programming Midterm
 *
 *  Created on April 22, 2016
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>
#include <sys/wait.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define DEBUG

#define SERVER_FIFO_NAME "serverFifo"
#define SIZE 255
#define FIFO_PERMS (S_IRWXU | S_IWGRP| S_IWOTH)
#define MAX_SIZE 1024

typedef struct logMessage{
	struct timespec currentTime;
	struct timespec connectTime;
	double mathResult;
	char operation[MAX_SIZE];
	char reasonTetmination[MAX_SIZE];
} log_t;

typedef struct clientMessage{
	
	char fifoName[SIZE];
	char function[SIZE];

}client_t;

struct timespec timeDiffNanosec(struct timespec start, struct timespec end);

ssize_t r_write(int fd, void *buf, size_t size);
int client(char* firstFile, char* secondFile,int timeInterval,char* aritmeticOperation);
static volatile sig_atomic_t doneflag = 0;
static volatile sig_atomic_t continueProgram = 1;


void sigAlarmHandler(int signal){
	doneflag = 1;
}

void sigIntHandler(int signal){
	continueProgram = 0;
}

int main(int argc, char *argv[])
{
	char aritmeticOperation[1];
	int timeInterval;
	int i;
	char fileName1[SIZE];
	char fileName2[SIZE];
	int requestfd, retval;
	long lifeTimeMicroseconds;
	struct sigaction act;
	

	
	/*Set signal handler for SIGALRM*/
	act.sa_handler = sigAlarmHandler;
	act.sa_flags = 0;
	if((sigemptyset(&act.sa_mask) || sigaction(SIGALRM, &act, NULL)) == -1){
		perror("Couldn't set signal handler for SIGALRM");
		return EXIT_FAILURE;
	}


	/*Set signal handler for SIGINT*/
	act.sa_handler = sigIntHandler;
	act.sa_flags = 0;
	if((sigemptyset(&act.sa_mask) || sigaction(SIGINT, &act, NULL)) == -1){
		perror("Couldn't set signal handler for SIGINT");
		return EXIT_FAILURE;
	}
	
	if(argc !=5 )
	{
		fprintf(stderr,"Usage: %s -<fi> -<fj> -<time interval(s)> -<operation>\n",argv[0]);
		return 1;
	}
	
	for (i = 1; i < 5; ++i)
	{
		if(argv[i][0] != '-')
		{
			fprintf(stderr,"You must add '-' each command except operation command.\n");
			fprintf(stderr,"Usage: %s -<fi> -<fj> -<time interval(s)> -<operation>\n",argv[0]);
			return 1;
		}
	}
	
	/* control arithmetical operations */
	if( (strcmp(&argv[4][1],"+")==0) )
		++i;/* this is not important */
	else if( (strcmp(&argv[4][1],"-")==0) )
		++i;/* this is not important */
	else if( (strcmp(&argv[4][1],"*")==0) )
		++i;/* this is not important */
	else if( (strcmp(&argv[4][1],"/")==0) )
		++i;/* this is not important */
	else{	
		fprintf(stderr,"Invalid arithmetic operation : %s ",argv[4]);		    
	    perror("Aritmetic operation must be one of +, -, /, * \n");
	    return 1;	    
    }
    
	strcpy(aritmeticOperation,&argv[4][1]);
	timeInterval = -atoi(argv[3]);
	
	strcpy(fileName1,&argv[1][1]);
	strcpy(fileName2,&argv[2][1]);
	
    client(fileName1,fileName2,timeInterval,aritmeticOperation);

	return 1;
}

int client(char* firstFile, char* secondFile,int timeInterval,char* aritmeticOperation)
{
	FILE* fpFile1;
	FILE* fpFile2;
	FILE* logFilePtr;
	char logFileName[20];	
	int requestfdServer;
	char buffer[MAX_SIZE];
	char result[MAX_SIZE];
	time_t tcurrent;
	char myClientFifo[SIZE];
	int  requestfdClient;
	char strFunc[10];
	client_t message;
	 
	sprintf(myClientFifo,"FifoClient_%d",getpid());
	
	/* create client's fifo*/
	if ((mkfifo(myClientFifo,FIFO_PERMS) == -1) && (errno != EEXIST))
	{
		perror("Client failed to create the fifo\n");
		return 1;
	}
		
	/*integrali alinacak fonksiyonu string haline getirdim*/
	sprintf(strFunc,"%s%s%s",firstFile,secondFile,aritmeticOperation);
	/* adding null character end of the buffer*/
	strFunc[strlen(strFunc)-1]='\0';
	
	/* client in olusturdugu fifo ismi ve integral fonksiyonu buffer yazildi.*/
	strcpy(message.function,strFunc);
	strcpy(message.fifoName,myClientFifo);	
	
	/* opened server fifo in write mode */
	if ((requestfdServer = open(SERVER_FIFO_NAME, O_WRONLY)) == -1)
	{
		if( unlink(SERVER_FIFO_NAME) == -1 )
		{
			perror("Client failed to remove the fifo\n");
			return 1;
		}
		exit(1);
	}
	
	/* ClientFifo nun ismini ve integrali alinacak fonksiyonu server fifo'ya yazdim */
	if(r_write(requestfdServer, &message, sizeof(client_t)) !=  sizeof(client_t)){
		perror("cannot write to to main fifo");
	}
	close(requestfdServer);

#ifdef DEBUG
	fprintf(stderr, "message: %s was written to %s,%s,fifo closed\n",message.function,message.fifoName,SERVER_FIFO_NAME );
	fprintf(stderr, "Client: Waiting to open fifo in write mode by server child...\n");
#endif

	/* clientFifo yu okuma modunda actim sonucu okuyacagim*/
	if ((requestfdClient = open(myClientFifo, O_RDONLY)) == -1)
	{
		if( unlink(myClientFifo) == -1 )
		{
			perror("Client failed to remove the fifo\n");
			return 1;
		}
		exit(1);
	}
	
	read(requestfdClient,result,MAX_SIZE);
#ifdef DEBUG
	fprintf(stderr, "message: %s was read from server child. closing fifo\n",result );
#endif

	/*open log file*/
	sprintf(logFileName,"ClientLogFile%ld",(long)getpid());
	logFilePtr = fopen(logFileName,"w");
	
	/* write connection time to log file*/
	tcurrent=time(NULL);
	fprintf(logFilePtr,"Connected Time: %s",ctime(&tcurrent));
	fflush(logFilePtr);	
		
	/*writing to function log file*/
	fprintf(logFilePtr,"Function:%s\n",strFunc);		
			
	fprintf(logFilePtr,"%s\n",result);
	close(requestfdClient);
	unlink(myClientFifo);
	return 0;
}

ssize_t r_write(int fd, void *buf, size_t size)
{
	char *bufp;
	size_t bytestowrite;
	ssize_t byteswritten;
	size_t totalbytes;

	for (bufp = buf, bytestowrite = size, totalbytes = 0;
		bytestowrite > 0;
		bufp += byteswritten, bytestowrite -= byteswritten)
	{
		byteswritten = write(fd, bufp, bytestowrite);
		if ((byteswritten) == -1 && (errno != EINTR))
			return -1;
		if (byteswritten == -1)
			byteswritten = 0;
		totalbytes += byteswritten;
	}
	return totalbytes;
}
